E-learning

PROJECT TITLE:Learning studio: An E-learning Website

OVERVIEW: Trade Treasure is an e-commerce website built on the VS Code editor. Utilizing HTML, CSS, and JavaScript, the website embodies a sleek and elegant design, featuring a white background, classy theme, vibrant orange buttons, and highlighted headings in black.

PROJECT JUSTIFICATION:

Resources and References: For guidance and inspiration, numerous tutorials, videos, and source codes were consulted via Google and YouTube. Custom features and enhancements were developed based on these references. Additionally, Google was utilized for shapes and logo creation, while images were sourced from Pinterest.

Difficulties Encountered: The development process posed several challenges, including encountering numerous coding errors, difficulty in finding suitable website imagery, struggling to finalize designs, and spending significant time debugging.
